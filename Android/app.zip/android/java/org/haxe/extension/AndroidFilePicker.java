package org.haxe.extension;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;

import org.haxe.lime.HaxeObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class AndroidFilePicker extends Extension {

    private static final int REQUEST_OPEN_DOCUMENT = 43192;
    private static final int REQUEST_CREATE_DOCUMENT = 43193;
    private static final int REQUEST_OPEN_TREE = 43194;
    private static HaxeObject callback;
    private static String pendingExtension = "";
    private static String pendingSaveSource = null;

    public static void setCallback(HaxeObject object) {
        callback = object;
    }

    public static void browseFile(final String title, final String extension) {
        final Activity activity = mainActivity;
        if (activity == null) {
            dispatchError("No encontré la actividad principal de Android.");
            return;
        }

        pendingExtension = extension == null ? "" : extension.trim().toLowerCase();

        activity.runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    String[] mimeTypes = resolveMimeTypes(pendingExtension);
                    intent.setType("*/*");
                    if (mimeTypes.length > 0) {
                        intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
                    }
                    intent.putExtra(Intent.EXTRA_LOCAL_ONLY, true);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);

                    if (title != null && !title.isEmpty()) {
                        intent.putExtra(Intent.EXTRA_TITLE, title);
                    }

                    activity.startActivityForResult(intent, REQUEST_OPEN_DOCUMENT);
                } catch (Exception e) {
                    dispatchError("No pude abrir el explorador del teléfono: " + e.getMessage());
                }
            }
        });
    }

    public static void browseDirectory(final String title) {
        final Activity activity = mainActivity;
        if (activity == null) {
            dispatchError("No encontré la actividad principal de Android.");
            return;
        }

        activity.runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    intent.addFlags(Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);

                    if (title != null && !title.isEmpty()) {
                        intent.putExtra(Intent.EXTRA_TITLE, title);
                    }

                    activity.startActivityForResult(intent, REQUEST_OPEN_TREE);
                } catch (Exception e) {
                    dispatchError("No pude abrir el selector de carpetas: " + e.getMessage());
                }
            }
        });
    }

    public static void saveFileToUser(final String title, final String suggestedName, final String sourcePath) {
        final Activity activity = mainActivity;
        if (activity == null) {
            dispatchError("No encontré la actividad principal de Android.");
            return;
        }

        if (sourcePath == null || sourcePath.trim().isEmpty()) {
            dispatchError("No encontré el ZIP temporal para guardar.");
            return;
        }

        File source = new File(sourcePath);
        if (!source.exists() || source.isDirectory()) {
            dispatchError("No encontré el archivo temporal: " + sourcePath);
            return;
        }

        pendingSaveSource = source.getAbsolutePath();

        activity.runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(resolveMimeTypeFromName(suggestedName));
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

                    if (title != null && !title.isEmpty()) {
                        intent.putExtra(Intent.EXTRA_TITLE, suggestedName == null || suggestedName.isEmpty() ? title : suggestedName);
                    } else if (suggestedName != null && !suggestedName.isEmpty()) {
                        intent.putExtra(Intent.EXTRA_TITLE, suggestedName);
                    }

                    activity.startActivityForResult(intent, REQUEST_CREATE_DOCUMENT);
                } catch (Exception e) {
                    dispatchError("No pude abrir el selector para guardar: " + e.getMessage());
                }
            }
        });
    }

    public static String getWorkspaceRoot() {
        Activity activity = mainActivity;
        if (activity == null) {
            return "";
        }
        return getWorkspaceDir(activity).getAbsolutePath();
    }

    public static String getExternalMediaRoot() {
        Activity activity = mainActivity;
        if (activity == null) {
            return "";
        }

        try {
            File[] mediaDirs = activity.getExternalMediaDirs();
            if (mediaDirs != null) {
                for (File dir : mediaDirs) {
                    if (dir == null) {
                        continue;
                    }
                    if (!dir.exists()) {
                        dir.mkdirs();
                    }
                    if (dir.exists() && dir.isDirectory()) {
                        return dir.getAbsolutePath();
                    }
                }
            }
        } catch (Exception ignored) {
        }

        try {
            File fallback = activity.getExternalFilesDir(null);
            if (fallback != null) {
                if (!fallback.exists()) {
                    fallback.mkdirs();
                }
                if (fallback.exists() && fallback.isDirectory()) {
                    return fallback.getAbsolutePath();
                }
            }
        } catch (Exception ignored) {
        }

        return "";
    }

    public static void clearWorkspace() {
        Activity activity = mainActivity;
        if (activity == null) {
            return;
        }

        File workspace = getWorkspaceDir(activity);
        deleteRecursively(workspace);
    }

    @Override public boolean onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_OPEN_DOCUMENT) {
            return handleOpenResult(resultCode, data);
        }

        if (requestCode == REQUEST_CREATE_DOCUMENT) {
            return handleSaveResult(resultCode, data);
        }

        if (requestCode == REQUEST_OPEN_TREE) {
            return handleTreeResult(resultCode, data);
        }

        return true;
    }

    private boolean handleOpenResult(int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) {
            dispatchCancel();
            return true;
        }

        final Activity activity = mainActivity;
        final Uri uri = data.getData();
        final String extension = pendingExtension;

        runInBackground("AndroidFilePickerOpen", new Runnable() {
            @Override public void run() {
                try {
                    try {
                        activity.getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (Exception ignored) {
                    }

                    String displayName = resolveDisplayName(activity, uri);
                    if (displayName == null || displayName.trim().isEmpty()) {
                        displayName = buildFallbackName(extension);
                    }

                    File targetDir = new File(getWorkspaceDir(activity), "picked-files");
                    if (!targetDir.exists()) {
                        targetDir.mkdirs();
                    }

                    File target = makeUniqueFile(targetDir, sanitizeName(displayName));
                    InputStream input = activity.getContentResolver().openInputStream(uri);
                    if (input == null) {
                        dispatchError("No pude leer el archivo seleccionado.");
                        return;
                    }

                    FileOutputStream output = new FileOutputStream(target, false);
                    copyStream(input, output);

                    dispatchPathSelected(target.getAbsolutePath());
                } catch (Exception e) {
                    dispatchError("Error procesando archivo: " + e.getMessage());
                }
            }
        });

        return true;
    }

    private boolean handleTreeResult(int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) {
            dispatchCancel();
            return true;
        }

        final Activity activity = mainActivity;
        final Uri treeUri = data.getData();
        final int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

        runInBackground("AndroidFilePickerTree", new Runnable() {
            @Override public void run() {
                try {
                    try {
                        activity.getContentResolver().takePersistableUriPermission(treeUri, flags);
                    } catch (Exception ignored) {
                    }

                    String treeDocumentId = DocumentsContract.getTreeDocumentId(treeUri);
                    Uri rootDocumentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, treeDocumentId);
                    String folderName = resolveDocumentDisplayName(activity, rootDocumentUri);
                    if (folderName == null || folderName.trim().isEmpty()) {
                        folderName = "imported-folder";
                    }

                    File spritemapsDir = new File(getExternalMediaRoot(), "spritemaps");
                    if (!spritemapsDir.exists()) {
                        spritemapsDir.mkdirs();
                    }

                    File targetDir = makeUniqueDirectory(spritemapsDir, sanitizeName(folderName));
                    if (!targetDir.exists()) {
                        targetDir.mkdirs();
                    }

                    copyDocumentTree(activity.getContentResolver(), treeUri, treeDocumentId, targetDir);
                    dispatchPathSelected(targetDir.getAbsolutePath());
                } catch (Exception e) {
                    dispatchError("Error importando carpeta: " + e.getMessage());
                }
            }
        });

        return true;
    }

    private boolean handleSaveResult(int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) {
            dispatchCancel();
            return true;
        }

        final Activity activity = mainActivity;
        final Uri uri = data.getData();

        if (pendingSaveSource == null || pendingSaveSource.isEmpty()) {
            dispatchError("No encontré el archivo temporal para guardar.");
            return true;
        }

        final String sourcePath = pendingSaveSource;
        pendingSaveSource = null;

        runInBackground("AndroidFilePickerSave", new Runnable() {
            @Override public void run() {
                try {
                    File source = new File(sourcePath);
                    if (!source.exists() || source.isDirectory()) {
                        dispatchError("El ZIP temporal ya no existe.");
                        return;
                    }

                    InputStream input = new FileInputStream(source);
                    OutputStream output = activity.getContentResolver().openOutputStream(uri, "w");
                    if (output == null) {
                        try {
                            input.close();
                        } catch (Exception ignored) {
                        }
                        dispatchError("No pude escribir el archivo destino.");
                        return;
                    }

                    copyStream(input, output);
                    dispatchFileSaved(uri.toString());
                } catch (Exception e) {
                    dispatchError("No pude guardar el ZIP: " + e.getMessage());
                }
            }
        });

        return true;
    }

    private static void copyStream(InputStream input, OutputStream output) throws Exception {
        byte[] buffer = new byte[8192];
        int read;

        try {
            while ((read = input.read(buffer)) != -1) {
                output.write(buffer, 0, read);
            }
            output.flush();
        } finally {
            try {
                output.close();
            } catch (Exception ignored) {
            }
            try {
                input.close();
            } catch (Exception ignored) {
            }
        }
    }

    private static void runInBackground(String name, Runnable runnable) {
        Thread thread = new Thread(runnable, name);
        thread.start();
    }

    private static void dispatchPathSelected(final String path) {
        final HaxeObject callbackObject = callback;
        if (callbackObject == null) {
            return;
        }

        runCallback(new Runnable() {
            @Override public void run() {
                callbackObject.call1("onPathSelected", path);
            }
        });
    }

    private static void dispatchFileSaved(final String path) {
        final HaxeObject callbackObject = callback;
        if (callbackObject == null) {
            return;
        }

        runCallback(new Runnable() {
            @Override public void run() {
                callbackObject.call1("onFileSaved", path);
            }
        });
    }

    private static void dispatchCancel() {
        pendingSaveSource = null;
        final HaxeObject callbackObject = callback;
        if (callbackObject == null) {
            return;
        }

        runCallback(new Runnable() {
            @Override public void run() {
                callbackObject.call0("onPickerCancelled");
            }
        });
    }

    private static void dispatchError(final String message) {
        final HaxeObject callbackObject = callback;
        if (callbackObject == null) {
            return;
        }

        runCallback(new Runnable() {
            @Override public void run() {
                callbackObject.call1("onPickerError", message == null ? "Error desconocido." : message);
            }
        });
    }

    private static void runCallback(Runnable runnable) {
        Activity activity = mainActivity;
        if (activity != null) {
            activity.runOnUiThread(runnable);
        } else {
            runnable.run();
        }
    }

    private static String resolveDisplayName(Activity activity, Uri uri) {
        Cursor cursor = null;

        try {
            cursor = activity.getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    return cursor.getString(index);
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        String last = uri.getLastPathSegment();
        return last != null ? last : null;
    }

    private static String resolveDocumentDisplayName(Activity activity, Uri documentUri) {
        Cursor cursor = null;

        try {
            cursor = activity.getContentResolver().query(
                documentUri,
                new String[] { DocumentsContract.Document.COLUMN_DISPLAY_NAME },
                null,
                null,
                null
            );
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                if (index >= 0) {
                    return cursor.getString(index);
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        String last = documentUri.getLastPathSegment();
        return last != null ? last : null;
    }

    private static void copyDocumentTree(ContentResolver resolver, Uri treeUri, String documentId, File targetDir) throws Exception {
        if (!targetDir.exists() && !targetDir.mkdirs()) {
            throw new Exception("No pude crear carpeta destino: " + targetDir.getAbsolutePath());
        }

        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, documentId);
        Cursor cursor = null;

        try {
            cursor = resolver.query(
                childrenUri,
                new String[] {
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE
                },
                null,
                null,
                null
            );

            if (cursor == null) {
                return;
            }

            int idIndex = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
            int nameIndex = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
            int mimeIndex = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);

            while (cursor.moveToNext()) {
                String childId = idIndex >= 0 ? cursor.getString(idIndex) : "";
                String displayName = nameIndex >= 0 ? cursor.getString(nameIndex) : "file";
                String mimeType = mimeIndex >= 0 ? cursor.getString(mimeIndex) : "";

                if (childId == null || childId.isEmpty()) {
                    continue;
                }

                File childTarget = new File(targetDir, sanitizeName(displayName == null ? "file" : displayName));
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mimeType)) {
                    copyDocumentTree(resolver, treeUri, childId, childTarget);
                } else {
                    Uri childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childId);
                    InputStream input = resolver.openInputStream(childUri);
                    if (input == null) {
                        continue;
                    }

                    FileOutputStream output = new FileOutputStream(makeUniqueFile(targetDir, sanitizeName(displayName)));
                    copyStream(input, output);
                }
            }
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    private static String buildFallbackName(String extension) {
        if (extension == null || extension.isEmpty()) {
            return "picked_file";
        }
        return "picked_file." + extension;
    }

    private static String sanitizeName(String value) {
        if (value == null) {
            value = buildFallbackName(pendingExtension);
        }
        String out = value.replace("/", "_").replace("\\", "_").replace(":", "_");
        if (out.isEmpty()) {
            out = buildFallbackName(pendingExtension);
        }
        return out;
    }

    private static String resolveMimeType(String extension) {
        if (extension == null || extension.isEmpty()) {
            return "*/*";
        }

        if (extension.equals("json")) return "application/json";
        if (extension.equals("xml")) return "text/xml";
        if (extension.equals("png")) return "image/png";
        if (extension.equals("jpg") || extension.equals("jpeg")) return "image/jpeg";
        if (extension.equals("zip")) return "application/zip";
        return "*/*";
    }

    private static String[] resolveMimeTypes(String extension) {
        if (extension == null || extension.isEmpty()) {
            return new String[0];
        }

        if (extension.equals("json")) return new String[] { "application/json", "text/json", "text/plain" };
        if (extension.equals("xml")) return new String[] { "text/xml", "application/xml", "text/plain" };
        if (extension.equals("png")) return new String[] { "image/png" };
        if (extension.equals("jpg") || extension.equals("jpeg")) return new String[] { "image/jpeg" };
        if (extension.equals("zip")) return new String[] { "application/zip", "application/octet-stream" };
        return new String[] { resolveMimeType(extension) };
    }

    private static String resolveMimeTypeFromName(String name) {
        if (name == null) {
            return "application/octet-stream";
        }

        String lower = name.toLowerCase();
        if (lower.endsWith(".zip")) return "application/zip";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".json")) return "application/json";
        if (lower.endsWith(".xml")) return "text/xml";
        return "application/octet-stream";
    }

    private static File getWorkspaceDir(Activity activity) {
        File workspace = new File(activity.getFilesDir(), "spritemap-to-funky");
        if (!workspace.exists()) {
            workspace.mkdirs();
        }
        return workspace;
    }

    private static File makeUniqueFile(File directory, String fileName) {
        File candidate = new File(directory, fileName);
        if (!candidate.exists()) {
            return candidate;
        }

        String name = fileName;
        String extension = "";
        int dot = fileName.lastIndexOf('.');
        if (dot >= 0) {
            name = fileName.substring(0, dot);
            extension = fileName.substring(dot);
        }

        int suffix = 1;
        while (candidate.exists()) {
            candidate = new File(directory, name + "_" + suffix + extension);
            suffix++;
        }

        return candidate;
    }

    private static File makeUniqueDirectory(File directory, String folderName) {
        File candidate = new File(directory, folderName);
        if (!candidate.exists()) {
            return candidate;
        }

        int suffix = 1;
        while (candidate.exists()) {
            candidate = new File(directory, folderName + "_" + suffix);
            suffix++;
        }

        return candidate;
    }

    private static void deleteRecursively(File file) {
        if (file == null || !file.exists()) {
            return;
        }

        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) {
                    deleteRecursively(child);
                }
            }
        }

        file.delete();
    }
}
